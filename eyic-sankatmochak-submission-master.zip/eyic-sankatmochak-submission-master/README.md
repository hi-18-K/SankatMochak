# eyic-sankatmochak-submission
This is our project submission for implementation sprint of eyic competition.

----------------------------

### Please download eyic-code-Team#111.zip
